/**
 * Created by ijaz0 on 11/1/2018.
 */
$('.message a').click(function(){
    $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});