<?php


/**
 * Class Configure
 */
class Configure{
    static $host = 'localhost',
            $user = 'root',
            $password = 'Darkweb360@.',
            $database = 'personal_ooplogin';
    
}